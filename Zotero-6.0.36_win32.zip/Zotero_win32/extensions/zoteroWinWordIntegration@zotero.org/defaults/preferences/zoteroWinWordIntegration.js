pref("extensions.zoteroWinWordIntegration.version", "");
pref("extensions.zoteroWinWordIntegration.installed", false);
pref("extensions.zoteroWinWordIntegration.skipInstallation", false);